var login_btn = document.getElementBy('login_btn'), 
    logout_btn = document.getElementById("logout_btn");
    user_image = document.getElementById("user_image");
   
var user_name_h1 = document.getElementById("user_name");


var googlelogin = function(){

var provider = new firebase.auth.GoogleAuthProvider();

firebase.auth()
  .signInWithPopup(provider)
  .then((result) => {
    /** @type {firebase.auth.OAuthCredential} */
    var credential = result.credential;

    // This gives you a Google Access Token. You can use it to access the Google API.
    var token = credential.accessToken;
    // The signed-in user info.
    var user = result.user;

    console.log(user.displayName);
    updateUser(user);
    // ...
  }).catch((error) => {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });  
}

//agregar datos de usuario
var updateUser = function(user){
    user_name_h1.innerHTML = "Hola," + user.displayName;
    user_image.src = user.photoURL;

    login_btn.style.display = "none";
    logout_btn.style.display = "inline-block";
}

var logout = function(){

  firebase.auth().signOut().then(() => {
  user_name_h1.innerHTML = ("Acceso")
  user_image.src = "imgs/logo.png";
  login_btn.style.display = "inline-block";
  logout_btn.style.display = "none";

}).catch((error) => {
  // An error happened.
});


}
