// For Firebase JavaScript SDK v7.20.0 and later, `measurementId` is an optional field
var firebaseConfig = {
  apiKey: "AIzaSyA_tkdZnjSO8tV1_o_LtwQUR_26i2vKXG4",
  authDomain: "eunacom-chile.firebaseapp.com",
  databaseURL: "https://eunacom-chile.firebaseio.com",
  projectId: "eunacom-chile",
  storageBucket: "eunacom-chile.appspot.com",
  };

   // Initialize Firebase
    firebase.initializeApp(firebaseConfig);